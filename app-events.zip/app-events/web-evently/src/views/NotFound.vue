<script setup lang="ts"></script>

<template>
    <div class="text-center py-20">
        <h1 class="text-3xl font-bold">404</h1>
        <p class="text-gray-500">Página no encontrada</p>
        <router-link
            to="/"
            class="inline-block mt-4 px-4 py-2 rounded-xl bg-gray-900 text-white"
            >Volver</router-link
        >
    </div>
</template>

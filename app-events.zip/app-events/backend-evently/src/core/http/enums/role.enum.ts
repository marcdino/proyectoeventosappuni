export enum Role {
    ADMIN = 'admin',
    ORGANIZER = 'organizer',
    ATTENDEE = 'attendee',
}